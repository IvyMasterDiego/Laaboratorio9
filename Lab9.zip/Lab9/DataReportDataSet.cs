﻿namespace Laboratorio9_WinApp_
{


    partial class DataReportDataSet
    {
        partial class tblClientesDataTable
        {
        }
    }
}

namespace Laboratorio9_WinApp_.DataReportDataSetTableAdapters {
    
    
    public partial class tblClientesTableAdapter {
    }
}
